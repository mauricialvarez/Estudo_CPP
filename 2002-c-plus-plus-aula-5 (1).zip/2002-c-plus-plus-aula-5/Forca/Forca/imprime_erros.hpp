#include <vector>

namespace Forca {
    void imprime_erros(const std::vector<char>& chutes_errados);
}