#include <string>
#include <map>

bool nao_acertou(std::string& palavra_secreta, const std::map<char, bool>& chutou);