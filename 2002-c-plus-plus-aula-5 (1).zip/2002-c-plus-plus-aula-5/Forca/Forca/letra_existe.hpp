#include <string>

bool letra_existe(char chute, std::string& palavra_secreta);