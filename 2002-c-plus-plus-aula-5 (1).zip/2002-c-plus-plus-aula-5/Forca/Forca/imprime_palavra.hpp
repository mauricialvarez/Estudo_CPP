#include <string>
#include <map>

void imprime_palavra(std::string& palavra_secreta, std::map<char, bool>& chutou);