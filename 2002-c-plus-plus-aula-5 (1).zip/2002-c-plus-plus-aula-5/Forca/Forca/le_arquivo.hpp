#pragma once
#include <vector>
#include <string>

std::vector<std::string> le_arquivo();