#include <string>

std::string sorteia_palavra();